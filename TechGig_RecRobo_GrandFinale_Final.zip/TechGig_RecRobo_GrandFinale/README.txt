
Uipath Main File To Run :-  RecRobo.xaml

Source Code :- Main.xaml


Prerequisites

1. Install python3 in system.
2. Install below mentioned python liabrary:-

1. pyttsx3
2. Opencv

Steps to Run Code:-

1. Unzip the folder.
2. Update path where python scripts are placed at config.txt