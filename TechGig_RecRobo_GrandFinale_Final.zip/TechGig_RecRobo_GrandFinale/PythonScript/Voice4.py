import os
import sys
import pyttsx3

engine = pyttsx3.init()
engine.say('Please Collect Your ID Card. We Are Happy To Serve You. Have A Nice Day. Thank You')
engine.runAndWait()
