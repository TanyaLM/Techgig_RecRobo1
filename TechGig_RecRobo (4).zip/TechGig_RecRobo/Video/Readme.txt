Main File :- RecRobo. (Use this xaml file)

Main :- Main.xaml (Its Reframe work)

1. First open Code.xlsm file from Data folder.
2. Click on Click me and select accordingly.

3. Once form filled run robot. :- If it's visitor then send email to robot with the Subject "Approved"

If Employee Radio button is selected then Use Employee ID from DUMMY DATABASE  placed in DATA FOLDER

4. All used files are present in Data folder.

5. All scripts are in Python_Script folder.

6. While running if any error please check file paths.

7. If any error in python script then double click on .bat file available in "Data Folder".

8. Presentation is available in Presentation folder.

9. Video is available in Video folder. 

10. Created Video only for Visitor Scenario. (Can run for All available scenario.).


NOTE:-  IN Video SOUND IS NOT AVAILABLE SO PLEASE READ PROJECT DESCRIPTION FIRST FOR UNDERSTANDING.