Main File :- RecRobo.

Main :- Main.xaml

1. First open Code.xlsm file from Data folder.
2. Click on Click me and select accordingly.
3. Once form filled run robot.
4. All used files are present in Data folder.
5. All scripts are in Python_Script folder.
6. While running if any error please check file paths.